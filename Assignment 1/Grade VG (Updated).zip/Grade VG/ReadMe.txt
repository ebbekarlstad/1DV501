sumofthree.py
For this exercise, I got the three digit number via user input, I then calculated the hundreds, tens and single digits of the three numbers in the three digit number using modulus and integer division in order to divide these into three different variables, a, b, and c. I then presented the result using a simple print() function.

change.py
This exercise was a bit harder, and took me a good hour or so to solve. I first got all the neccessary information from user input. I then calculated the change and also the number of denominations (1000kr bills, 500kr bills etc.), the latter which was done by, again, using modulus and integer divison. After this I printed the results so that both the change as well as the number of denominations required to cover the change could be seen.

tax.py
For this one, I first got the monthly income via user input, and also converted it to an integer. I then defined the different tax rates, multiplying the original and the two "extra" taxes by 0.01, as well as adding 5 to the extra tax (for monthly incomes over 38000) and 10 to the second extra tax (for monthly incomes over 50000). I then calculated the different taxes by using regular multiplications, modulus and if and else if (elif) statements to check which of the different zones the incomes belongs to. After this I printed out the results.

squarecolor.py
I first got the chess identifier (eg. e5) from user input. I then got the letter and number from that very identifier, for later use. After this I checked if the letter from the identifier belonged to "aceg" or "bdfh" and if the number from the identifier was odd or even. I then set the square_color variable to black or white, depending on the two prevoius "calculations". After this I printed out the results.